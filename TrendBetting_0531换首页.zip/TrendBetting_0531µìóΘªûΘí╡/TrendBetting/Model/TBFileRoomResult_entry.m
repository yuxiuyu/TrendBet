//
//  TBFileRoomResult_entry.m
//  TrendBetting
//
//  Created by jiazhen-mac-01 on 17/2/13.
//  Copyright © 2017年 yxy. All rights reserved.
//

#import "TBFileRoomResult_entry.h"
#import "TBFileRoomResult_roomArr.h"
@implementation TBFileRoomResult_entry
+(NSDictionary*)mj_objectClassInArray
{
    return @{@"roomArr":@"TBFileRoomResult_roomArr"};
}
@end
