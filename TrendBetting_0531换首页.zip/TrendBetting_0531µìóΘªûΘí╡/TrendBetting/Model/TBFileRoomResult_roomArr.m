//
//  TBFileRoomResult_roomArr.m
//  TrendBetting
//
//  Created by jiazhen-mac-01 on 17/2/13.
//  Copyright © 2017年 yxy. All rights reserved.
//

#import "TBFileRoomResult_roomArr.h"
#import "TBFileRoomResult_timeArr.h"
@implementation TBFileRoomResult_roomArr
+(NSDictionary*)mj_objectClassInArray
{
    return @{@"timeArr":@"TBFileRoomResult_timeArr"};
}
@end
