//
//  TBFileRoomResult_entry.h
//  TrendBetting
//
//  Created by jiazhen-mac-01 on 17/2/13.
//  Copyright © 2017年 yxy. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface TBFileRoomResult_entry : NSObject
@property(copy,nonatomic)NSArray*roomArr;//房间号

@end
