//
//  TBFileRoomResult_timeArr.m
//  TrendBetting
//
//  Created by jiazhen-mac-01 on 17/2/13.
//  Copyright © 2017年 yxy. All rights reserved.
//

#import "TBFileRoomResult_timeArr.h"
#import "TBFileRoomResult_dataArr.h"
@implementation TBFileRoomResult_timeArr
+(NSDictionary*)mj_objectClassInArray
{
    return @{@"dataArr":@"TBFileRoomResult_dataArr"};
}
@end
