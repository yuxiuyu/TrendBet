//
//  TBFileRoomResult_dataArr.m
//  TrendBetting
//
//  Created by jiazhen-mac-01 on 17/2/13.
//  Copyright © 2017年 yxy. All rights reserved.
//

#import "TBFileRoomResult_dataArr.h"

@implementation TBFileRoomResult_dataArr

@end
