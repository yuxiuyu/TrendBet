//
//  TBFileRoomResult_timeArr.h
//  TrendBetting
//
//  Created by jiazhen-mac-01 on 17/2/13.
//  Copyright © 2017年 yxy. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface TBFileRoomResult_timeArr : NSObject
@property(copy,nonatomic)NSString*time;
@property(strong,nonatomic)NSArray*dataArr;
@end
