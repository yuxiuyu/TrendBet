//
//  chartView.h
//  ExcelViewDemol
//
//  Created by jiazhen-mac-01 on 17/1/4.
//  Copyright © 2017年 chedaye. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface chartImageView : UIView
@property(nonatomic,strong)NSArray*itemArray;
@property (assign, nonatomic) NSInteger myType;


@end
