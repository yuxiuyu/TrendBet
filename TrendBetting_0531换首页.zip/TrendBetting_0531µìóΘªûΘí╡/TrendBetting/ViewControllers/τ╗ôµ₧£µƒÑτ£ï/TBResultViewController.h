//
//  TBResultRoomViewController.h
//  TrendBetting
//
//  Created by jiazhen-mac-01 on 17/2/15.
//  Copyright © 2017年 yxy. All rights reserved.
//

#import "TBBaseViewController.h"
#import "Utils+rule.h"
@interface TBResultViewController : TBBaseViewController
//@property(assign,nonatomic)TBTrendCode selectedTrendCode;
@property (weak, nonatomic) IBOutlet UITableView *tableview;
@end
