//
//  TBNewRule_RoomViewController.h
//  TrendBetting
//
//  Created by jiazhen-mac-01 on 17/6/20.
//  Copyright © 2017年 yxy. All rights reserved.
//

#import "TBBaseViewController.h"

@interface TBNewRule_RoomViewController : TBBaseViewController

@end
@interface newroomCollectionViewCell : UICollectionViewCell
@property (weak, nonatomic) IBOutlet UILabel *roomLab;
@property (weak, nonatomic) IBOutlet UILabel *resultCountLab;

@end
