//
//  TBSettingViewController.h
//  TrendBetting
//
//  Created by jiazhen-mac-01 on 17/3/7.
//  Copyright © 2017年 yxy. All rights reserved.
//

#import "TBBaseViewController.h"
@interface TBSettingViewController : TBBaseViewController
@property (weak, nonatomic) IBOutlet UITableView *tableview;
@end
