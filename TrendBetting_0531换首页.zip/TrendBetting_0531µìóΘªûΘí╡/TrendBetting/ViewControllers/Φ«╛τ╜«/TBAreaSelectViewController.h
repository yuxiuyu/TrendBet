//
//  TBAreaViewController.h
//  TrendBetting
//
//  Created by jiazhen-mac-01 on 17/3/3.
//  Copyright © 2017年 yxy. All rights reserved.
//

#import "TBBaseViewController.h"

@interface TBAreaSelectViewController : TBBaseViewController

@property (weak, nonatomic) IBOutlet UITableView *tableview;
@end
