//
//  TBMonthViewController.h
//  TrendBetting
//
//  Created by WX on 2017/10/19.
//  Copyright © 2017年 yxy. All rights reserved.
//

#import "TBBaseViewController.h"

@interface monthCell : UITableViewCell

@end

@interface TBMonthViewController : TBBaseViewController

@property(nonatomic,strong) NSString *selectedRoom;

@end
