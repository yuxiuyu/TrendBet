//
//  TBDown_RoomViewController.h
//  TrendBetting
//
//  Created by 于秀玉 on 17/10/19.
//  Copyright © 2017年 yxy. All rights reserved.
//

#import "TBBaseViewController.h"

@interface TBDown_RoomViewController : TBBaseViewController

@end

@interface downroomCollectionViewCell : UICollectionViewCell
@property (weak, nonatomic) IBOutlet UILabel *roomLab;


@end
