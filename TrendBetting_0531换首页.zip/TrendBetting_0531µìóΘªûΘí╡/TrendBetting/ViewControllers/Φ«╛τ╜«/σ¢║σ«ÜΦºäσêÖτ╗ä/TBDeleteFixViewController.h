//
//  TBDeleteFixViewController.h
//  TrendBetting
//
//  Created by 于秀玉 on 17/9/17.
//  Copyright © 2017年 yxy. All rights reserved.
//

#import "TBBaseViewController.h"

@interface TBDeleteFixViewController : TBBaseViewController
@property (weak, nonatomic) IBOutlet UITableView *tableview;
@end
