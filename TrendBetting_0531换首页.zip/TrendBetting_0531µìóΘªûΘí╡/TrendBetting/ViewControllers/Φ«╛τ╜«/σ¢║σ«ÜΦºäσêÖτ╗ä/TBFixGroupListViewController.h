//
//  TBFixGroupListViewController.h
//  TrendBetting
//
//  Created by jiazhen-mac-01 on 2017/9/15.
//  Copyright © 2017年 yxy. All rights reserved.
//

#import "TBBaseViewController.h"

@interface TBFixGroupListViewController : TBBaseViewController
@property (weak, nonatomic) IBOutlet UITableView *tableview;
@end
