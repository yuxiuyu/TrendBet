//
//  TBGroupListViewController.h
//  TrendBetting
//
//  Created by jiazhen-mac-01 on 17/4/19.
//  Copyright © 2017年 yxy. All rights reserved.
//

#import "TBBaseViewController.h"

@interface TBGroupListViewController : TBBaseViewController
@property (weak, nonatomic) IBOutlet UITableView *tableview;

@end
