//
//  TBOnlyRBSelectViewController.h
//  TrendBetting
//
//  Created by jiazhen-mac-01 on 17/7/17.
//  Copyright © 2017年 yxy. All rights reserved.
//

#import "TBBaseViewController.h"

@interface TBOnlyRBSelectViewController : TBBaseViewController
@property (weak, nonatomic) IBOutlet UITableView *tableview;
@end
