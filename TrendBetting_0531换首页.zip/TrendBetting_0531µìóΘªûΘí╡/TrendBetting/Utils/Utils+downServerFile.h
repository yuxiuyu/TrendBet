//
//  Utils+downServerFile.h
//  TrendBetting
//
//  Created by 于秀玉 on 17/10/18.
//  Copyright © 2017年 yxy. All rights reserved.
//

#import "Utils.h"

@interface Utils (downServerFile)
//下载文件
-(void)downLoadServerFile:(NSString*)roomStr timeStr:(NSString*)timeStr;
@end
 
